﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Pulsar
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Storyboard ImpactSidePanel;
        private Storyboard ExpandSidePanel;

        public MainWindow()
        {
            InitializeComponent();

            ImpactSidePanel = (Storyboard)FindResource("Impact_SidePanel");
            ExpandSidePanel = (Storyboard)FindResource("Expand_SidePanel");

            SizeChanged += MainWindow_SizeChanged;

            if (Width <= 1100)
            {
                ImpactSidePanel.Begin(this);
            }
            else
            {
                ExpandSidePanel.Begin(this);
            }
        }

        private void MainWindow_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (Width <= 1100)
            {
                ImpactSidePanel.Begin(this);
            }
            else
            {
                ExpandSidePanel.Begin(this);
            }
        }

        private void titleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }
    }
}